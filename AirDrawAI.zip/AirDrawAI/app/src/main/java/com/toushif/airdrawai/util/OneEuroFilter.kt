package com.toushif.airdrawai.util

import kotlin.math.PI
import kotlin.math.abs

/**
 * One Euro Filter — a low-latency, adaptive low-pass filter well suited for
 * smoothing noisy real-time signals such as a tracked fingertip position.
 *
 * Reference: Casiez, Roussel, Vogel. "1€ Filter: A Simple Speed-based
 * Low-pass Filter for Noisy Input in Interactive Systems" (CHI 2012).
 *
 * Two independent instances are used for the X and Y coordinate streams
 * (see [PointOneEuroFilter]).
 *
 * @param minCutoff Minimum cutoff frequency. Lower = smoother but more lag.
 * @param beta Speed coefficient. Higher = less lag during fast motion, but more jitter.
 * @param dCutoff Cutoff frequency used for filtering the derivative.
 */
class OneEuroFilter(
    private var minCutoff: Double = 1.0,
    private var beta: Double = 0.15,
    private var dCutoff: Double = 1.0
) {
    private var isInitialized = false
    private var xPrev = 0.0
    private var dxPrev = 0.0
    private var tPrev = 0L

    private fun smoothingFactor(te: Double, cutoff: Double): Double {
        val r = 2 * PI * cutoff * te
        return r / (r + 1)
    }

    private fun exponentialSmoothing(a: Double, x: Double, xPrevValue: Double): Double {
        return a * x + (1 - a) * xPrevValue
    }

    /**
     * Filters a new sample [x] captured at [timestampNanos]. Returns the
     * smoothed value.
     */
    fun filter(x: Double, timestampNanos: Long): Double {
        if (!isInitialized) {
            isInitialized = true
            xPrev = x
            dxPrev = 0.0
            tPrev = timestampNanos
            return x
        }

        var te = (timestampNanos - tPrev) / 1_000_000_000.0
        if (te <= 0.0) te = 1.0 / 60.0 // guard against non-monotonic timestamps
        tPrev = timestampNanos

        val dx = (x - xPrev) / te
        val aD = smoothingFactor(te, dCutoff)
        val dxHat = exponentialSmoothing(aD, dx, dxPrev)

        val cutoff = minCutoff + beta * abs(dxHat)
        val a = smoothingFactor(te, cutoff)
        val xHat = exponentialSmoothing(a, x, xPrev)

        xPrev = xHat
        dxPrev = dxHat
        return xHat
    }

    fun reset() {
        isInitialized = false
    }
}

/**
 * Convenience wrapper that filters a 2D point (x, y) using two independent
 * [OneEuroFilter] instances.
 */
class PointOneEuroFilter(
    minCutoff: Double = 1.0,
    beta: Double = 0.15,
    dCutoff: Double = 1.0
) {
    private val xFilter = OneEuroFilter(minCutoff, beta, dCutoff)
    private val yFilter = OneEuroFilter(minCutoff, beta, dCutoff)

    fun filter(x: Float, y: Float, timestampNanos: Long): Pair<Float, Float> {
        val fx = xFilter.filter(x.toDouble(), timestampNanos).toFloat()
        val fy = yFilter.filter(y.toDouble(), timestampNanos).toFloat()
        return fx to fy
    }

    fun reset() {
        xFilter.reset()
        yFilter.reset()
    }
}
