package com.toushif.airdrawai.drawing

import android.graphics.Color
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.toushif.airdrawai.model.ColorOption
import com.toushif.airdrawai.model.HandGesture

/**
 * Holds all UI/selection state for the drawing screen so it survives
 * configuration changes. Actual stroke pixel data lives in [DrawingView]
 * (see class doc there for the rationale); this ViewModel is the
 * single source of truth for everything else: selected color, brush size,
 * camera facing, flash state, current gesture/status, and undo/redo
 * availability mirrored from the view.
 */
class DrawingViewModel : ViewModel() {

    val availableColors: List<ColorOption> = listOf(
        ColorOption("Red", Color.parseColor("#F44336")),
        ColorOption("Blue", Color.parseColor("#2196F3")),
        ColorOption("Green", Color.parseColor("#4CAF50")),
        ColorOption("Yellow", Color.parseColor("#FFEB3B")),
        ColorOption("White", Color.parseColor("#FFFFFF")),
        ColorOption("Black", Color.parseColor("#000000"))
    )

    private val _selectedColor = MutableLiveData(availableColors.first().colorInt)
    val selectedColor: LiveData<Int> = _selectedColor

    private val _brushSizePx = MutableLiveData(24f)
    val brushSizePx: LiveData<Float> = _brushSizePx

    private val _currentGesture = MutableLiveData(HandGesture.NONE)
    val currentGesture: LiveData<HandGesture> = _currentGesture

    private val _isFrontCamera = MutableLiveData(true)
    val isFrontCamera: LiveData<Boolean> = _isFrontCamera

    private val _isFlashOn = MutableLiveData(false)
    val isFlashOn: LiveData<Boolean> = _isFlashOn

    private val _canUndo = MutableLiveData(false)
    val canUndo: LiveData<Boolean> = _canUndo

    private val _canRedo = MutableLiveData(false)
    val canRedo: LiveData<Boolean> = _canRedo

    private val _currentFps = MutableLiveData(0)
    val currentFps: LiveData<Int> = _currentFps

    private val _handDetected = MutableLiveData(false)
    val handDetected: LiveData<Boolean> = _handDetected

    fun selectColor(colorInt: Int) {
        _selectedColor.value = colorInt
    }

    fun setBrushSize(px: Float) {
        _brushSizePx.value = px
    }

    fun updateGesture(gesture: HandGesture) {
        if (_currentGesture.value != gesture) {
            _currentGesture.value = gesture
        }
    }

    fun updateHandDetected(detected: Boolean) {
        if (_handDetected.value != detected) {
            _handDetected.value = detected
        }
    }

    fun toggleCameraFacing() {
        _isFrontCamera.value = _isFrontCamera.value != true
    }

    fun toggleFlash() {
        _isFlashOn.value = _isFlashOn.value != true
    }

    /** Flash is only meaningful on the back camera. */
    fun setFlashAvailable(available: Boolean) {
        if (!available) _isFlashOn.value = false
    }

    fun updateHistoryState(canUndo: Boolean, canRedo: Boolean) {
        _canUndo.value = canUndo
        _canRedo.value = canRedo
    }

    fun updateFps(fps: Int) {
        _currentFps.value = fps
    }
}
