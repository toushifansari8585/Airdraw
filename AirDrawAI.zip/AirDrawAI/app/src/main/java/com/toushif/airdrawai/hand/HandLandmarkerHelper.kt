package com.toushif.airdrawai.hand

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import androidx.camera.core.ImageProxy
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult

/**
 * Thin wrapper around MediaPipe Tasks Vision's [HandLandmarker] configured
 * for LIVE_STREAM mode, driven by CameraX's [ImageProxy] frames.
 *
 * All heavy lifting (model inference) happens off the main thread on the
 * executor supplied by the caller; results are delivered asynchronously via
 * [HandLandmarkerListener].
 */
class HandLandmarkerHelper(
    private val context: Context,
    private val listener: HandLandmarkerListener,
    var minHandDetectionConfidence: Float = 0.5f,
    var minHandTrackingConfidence: Float = 0.5f,
    var minHandPresenceConfidence: Float = 0.5f,
    var maxNumHands: Int = 1,
    private val runningMode: RunningMode = RunningMode.LIVE_STREAM
) {

    private var handLandmarker: HandLandmarker? = null

    interface HandLandmarkerListener {
        fun onResults(resultBundle: ResultBundle)
        fun onError(error: String)
    }

    data class ResultBundle(
        val result: HandLandmarkerResult,
        val inferenceTimeMs: Long,
        val inputImageHeight: Int,
        val inputImageWidth: Int
    )

    init {
        setupHandLandmarker()
    }

    private fun setupHandLandmarker() {
        try {
            val baseOptionsBuilder = BaseOptions.builder()
                .setModelAssetPath(MODEL_PATH)
                .setDelegate(Delegate.GPU)

            val baseOptions = try {
                baseOptionsBuilder.build()
            } catch (gpuFailure: Exception) {
                // Fall back to CPU if the device has no usable GPU delegate.
                Log.w(TAG, "GPU delegate unavailable, falling back to CPU", gpuFailure)
                BaseOptions.builder()
                    .setModelAssetPath(MODEL_PATH)
                    .setDelegate(Delegate.CPU)
                    .build()
            }

            val optionsBuilder = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(baseOptions)
                .setMinHandDetectionConfidence(minHandDetectionConfidence)
                .setMinTrackingConfidence(minHandTrackingConfidence)
                .setMinHandPresenceConfidence(minHandPresenceConfidence)
                .setNumHands(maxNumHands)
                .setRunningMode(runningMode)

            if (runningMode == RunningMode.LIVE_STREAM) {
                optionsBuilder
                    .setResultListener(this::onResult)
                    .setErrorListener(this::onError)
            }

            handLandmarker = HandLandmarker.createFromOptions(context, optionsBuilder.build())
        } catch (e: IllegalStateException) {
            listener.onError("Hand Landmarker failed to initialize: ${e.message}")
            Log.e(TAG, "MediaPipe init failed", e)
        } catch (e: RuntimeException) {
            listener.onError(
                "Hand Landmarker failed to load model. Ensure hand_landmarker.task " +
                    "is present in app/src/main/assets. (${e.message})"
            )
            Log.e(TAG, "MediaPipe model load failed", e)
        }
    }

    fun isClosed(): Boolean = handLandmarker == null

    /**
     * Detects hand landmarks in a single [ImageProxy] frame from CameraX.
     * The proxy is converted to a [Bitmap], rotated to match its declared
     * rotation, and closed by the caller. Detection results are delivered
     * asynchronously to [listener] since this uses LIVE_STREAM mode.
     */
    fun detectAsync(bitmap: Bitmap, frameTimeMs: Long, isFrontCamera: Boolean) {
        val mpImage: MPImage = BitmapImageBuilder(bitmap).build()
        handLandmarker?.detectAsync(mpImage, frameTimeMs)
    }

    private fun onResult(result: HandLandmarkerResult, input: MPImage) {
        listener.onResults(
            ResultBundle(
                result = result,
                inferenceTimeMs = 0L,
                inputImageHeight = input.height,
                inputImageWidth = input.width
            )
        )
    }

    private fun onError(error: RuntimeException) {
        listener.onError(error.message ?: "Unknown Hand Landmarker error")
    }

    fun clear() {
        handLandmarker?.close()
        handLandmarker = null
    }

    companion object {
        private const val TAG = "HandLandmarkerHelper"
        const val MODEL_PATH = "hand_landmarker.task"
    }
}
