package com.toushif.airdrawai.drawing

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.util.AttributeSet
import android.view.View
import com.toushif.airdrawai.model.Stroke

/**
 * Renders completed and in-progress freehand strokes on a transparent
 * overlay that sits above the camera preview.
 *
 * Ownership model: this view is the single source of truth for stroke data
 * (completed strokes + undo/redo stacks). The ViewModel owns *selection*
 * state (current color/brush size/mode) and pushes it in via the public
 * setters below; the view reports history changes back out via
 * [HistoryListener] so the ViewModel/Activity can enable/disable undo-redo
 * buttons without duplicating the stroke list.
 */
class DrawingView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    interface HistoryListener {
        fun onHistoryChanged(canUndo: Boolean, canRedo: Boolean)
    }

    var historyListener: HistoryListener? = null

    private val completedStrokes = mutableListOf<Stroke>()
    private val redoStack = mutableListOf<Stroke>()
    private var activeStroke: Stroke? = null
    private var activePath: Path? = null

    // Cached Path objects per completed stroke, rebuilt only when strokes change,
    // to avoid re-walking every point on every single frame draw.
    private val strokePathCache = HashMap<Stroke, Path>()

    var currentColor: Int = Color.RED
    var currentBrushWidthPx: Float = 24f

    private val basePaint = Paint().apply {
        isAntiAlias = true
        isDither = true
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }

    private val eraserPaint = Paint().apply {
        isAntiAlias = true
        isDither = true
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    private var offscreenBitmap: Bitmap? = null
    private var offscreenCanvas: Canvas? = null

    init {
        // PorterDuff.CLEAR (used by the eraser) requires a software-rendered
        // layer to work correctly; hardware layers ignore CLEAR compositing.
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w > 0 && h > 0) {
            offscreenBitmap?.recycle()
            offscreenBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            offscreenCanvas = Canvas(offscreenBitmap!!)
            redrawOffscreen()
        }
    }

    /** Begins a new stroke at the given point (view coordinates). */
    fun startStroke(point: PointF, isEraser: Boolean) {
        val stroke = Stroke(
            points = mutableListOf(point),
            color = if (isEraser) Color.TRANSPARENT else currentColor,
            strokeWidth = currentBrushWidthPx,
            isEraser = isEraser
        )
        activeStroke = stroke
        activePath = Path().apply { moveTo(point.x, point.y) }
        redoStack.clear()
        notifyHistoryChanged()
    }

    /** Appends a point to the in-progress stroke using a quad-smoothed segment. */
    fun addPoint(point: PointF) {
        val stroke = activeStroke ?: return
        val path = activePath ?: return
        val last = stroke.points.lastOrNull()
        if (last != null) {
            val midX = (last.x + point.x) / 2f
            val midY = (last.y + point.y) / 2f
            path.quadTo(last.x, last.y, midX, midY)
        }
        stroke.points.add(point)
        invalidate()
    }

    /** Finalizes the in-progress stroke, committing it to the completed list. */
    fun endStroke() {
        val stroke = activeStroke ?: return
        if (stroke.points.size < 2) {
            // Treat a tap/dot as a tiny stroke so it's still visible.
            stroke.points.add(PointF(stroke.points[0].x + 0.1f, stroke.points[0].y + 0.1f))
        }
        completedStrokes.add(stroke)
        strokePathCache[stroke] = activePath ?: buildPath(stroke)
        drawStrokeToOffscreen(stroke)
        activeStroke = null
        activePath = null
        notifyHistoryChanged()
        invalidate()
    }

    fun cancelActiveStroke() {
        activeStroke = null
        activePath = null
        invalidate()
    }

    fun undo(): Boolean {
        if (completedStrokes.isEmpty()) return false
        val stroke = completedStrokes.removeAt(completedStrokes.size - 1)
        strokePathCache.remove(stroke)
        redoStack.add(stroke)
        redrawOffscreen()
        notifyHistoryChanged()
        invalidate()
        return true
    }

    fun redo(): Boolean {
        if (redoStack.isEmpty()) return false
        val stroke = redoStack.removeAt(redoStack.size - 1)
        completedStrokes.add(stroke)
        strokePathCache[stroke] = buildPath(stroke)
        drawStrokeToOffscreen(stroke)
        notifyHistoryChanged()
        invalidate()
        return true
    }

    fun clearCanvas() {
        completedStrokes.clear()
        redoStack.clear()
        strokePathCache.clear()
        activeStroke = null
        activePath = null
        redrawOffscreen()
        notifyHistoryChanged()
        invalidate()
    }

    fun canUndo(): Boolean = completedStrokes.isNotEmpty()
    fun canRedo(): Boolean = redoStack.isNotEmpty()

    /** Returns a flattened bitmap of everything drawn, at view resolution, transparent background. */
    fun exportBitmap(): Bitmap {
        val bmp = Bitmap.createBitmap(width.coerceAtLeast(1), height.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        offscreenBitmap?.let { canvas.drawBitmap(it, 0f, 0f, null) }
        activeStroke?.let { drawStroke(canvas, it, activePath) }
        return bmp
    }

    private fun buildPath(stroke: Stroke): Path {
        val path = Path()
        val pts = stroke.points
        if (pts.isEmpty()) return path
        path.moveTo(pts[0].x, pts[0].y)
        for (i in 1 until pts.size) {
            val prev = pts[i - 1]
            val curr = pts[i]
            val midX = (prev.x + curr.x) / 2f
            val midY = (prev.y + curr.y) / 2f
            path.quadTo(prev.x, prev.y, midX, midY)
        }
        return path
    }

    private fun redrawOffscreen() {
        val canvas = offscreenCanvas ?: return
        canvas.drawColor(0, PorterDuff.Mode.CLEAR)
        for (stroke in completedStrokes) {
            val path = strokePathCache.getOrPut(stroke) { buildPath(stroke) }
            drawPath(canvas, path, stroke)
        }
    }

    private fun drawStrokeToOffscreen(stroke: Stroke) {
        val canvas = offscreenCanvas ?: return
        val path = strokePathCache[stroke] ?: buildPath(stroke)
        drawPath(canvas, path, stroke)
    }

    private fun drawPath(canvas: Canvas, path: Path, stroke: Stroke) {
        val paint = if (stroke.isEraser) eraserPaint else basePaint
        paint.strokeWidth = stroke.strokeWidth
        if (!stroke.isEraser) paint.color = stroke.color
        canvas.drawPath(path, paint)
    }

    private fun drawStroke(canvas: Canvas, stroke: Stroke, path: Path?) {
        val p = path ?: buildPath(stroke)
        drawPath(canvas, p, stroke)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        offscreenBitmap?.let { canvas.drawBitmap(it, 0f, 0f, null) }
        val stroke = activeStroke
        val path = activePath
        if (stroke != null && path != null) {
            drawPath(canvas, path, stroke)
        }
    }

    private fun notifyHistoryChanged() {
        historyListener?.onHistoryChanged(canUndo(), canRedo())
    }
}
