package com.toushif.airdrawai

import android.content.Intent
import android.graphics.Color
import android.graphics.PointF
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.ImageButton
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import androidx.core.view.isVisible
import androidx.lifecycle.ViewModelProvider
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.toushif.airdrawai.camera.CameraController
import com.toushif.airdrawai.databinding.ActivityMainBinding
import com.toushif.airdrawai.drawing.DrawingViewModel
import com.toushif.airdrawai.gesture.GestureRecognizer
import com.toushif.airdrawai.hand.HandLandmarkerHelper
import com.toushif.airdrawai.model.ColorOption
import com.toushif.airdrawai.model.HandGesture
import com.toushif.airdrawai.model.HandLandmark
import com.toushif.airdrawai.util.CoordinateMapper
import com.toushif.airdrawai.util.ImageSaver
import com.toushif.airdrawai.util.ImageUtils
import com.toushif.airdrawai.util.PermissionUtils
import com.toushif.airdrawai.util.PointOneEuroFilter
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity(), HandLandmarkerHelper.HandLandmarkerListener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: DrawingViewModel
    private lateinit var cameraController: CameraController

    private var handLandmarkerHelper: HandLandmarkerHelper? = null
    private val gestureRecognizer = GestureRecognizer()
    private val fingertipFilter = PointOneEuroFilter(minCutoff = 1.2, beta = 0.4)

    private var isDrawingActive = true
    private var wasDrawingLastFrame = false
    private var wasErasingLastFrame = false

    // FPS tracking
    private var frameCount = 0
    private var lastFpsTimestamp = System.currentTimeMillis()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        if (grants[android.Manifest.permission.CAMERA] == true) {
            onPermissionGranted()
        } else {
            showPermissionDenied()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this)[DrawingViewModel::class.java]
        cameraController = CameraController(this, this)

        setupColorPicker()
        setupControlListeners()
        observeViewModel()

        if (PermissionUtils.allPermissionsGranted(this)) {
            onPermissionGranted()
        } else {
            requestPermissions()
        }
    }

    // region Permissions

    private fun requestPermissions() {
        binding.permissionOverlay.isVisible = true
        binding.permissionMessage.text = getString(R.string.permission_camera_rationale)
        binding.btnGrantPermission.text = getString(R.string.grant_permission)
        binding.btnGrantPermission.setOnClickListener {
            permissionLauncher.launch(PermissionUtils.requiredPermissions())
        }
    }

    private fun onPermissionGranted() {
        binding.permissionOverlay.isVisible = false
        initHandLandmarker()
        startCamera()
    }

    private fun showPermissionDenied() {
        binding.permissionOverlay.isVisible = true
        binding.permissionMessage.text = getString(R.string.permission_denied_message)
        binding.btnGrantPermission.text = getString(R.string.open_settings)
        binding.btnGrantPermission.setOnClickListener {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", packageName, null)
            }
            startActivity(intent)
        }
    }

    // endregion

    // region Setup

    private fun initHandLandmarker() {
        handLandmarkerHelper = HandLandmarkerHelper(
            context = this,
            listener = this,
            maxNumHands = 1
        )
    }

    private fun startCamera() {
        val useFront = viewModel.isFrontCamera.value ?: true
        cameraController.startCamera(
            previewView = binding.previewView,
            useFrontCamera = useFront,
            onFrame = { proxy -> analyzeFrame(proxy) },
            onBound = {
                viewModel.setFlashAvailable(cameraController.hasFlashUnit())
            }
        )
    }

    private fun analyzeFrame(imageProxy: androidx.camera.core.ImageProxy) {
        try {
            val isFront = cameraController.isFrontCamera()
            val bitmap = ImageUtils.imageProxyToBitmap(imageProxy, isFront)
            handLandmarkerHelper?.detectAsync(
                bitmap = bitmap,
                frameTimeMs = System.currentTimeMillis(),
                isFrontCamera = isFront
            )
        } catch (e: Exception) {
            Log.e(TAG, "Frame analysis failed", e)
        } finally {
            imageProxy.close()
        }
    }

    private fun setupColorPicker() {
        binding.colorPickerRow.removeAllViews()
        val swatchSize = resources.getDimensionPixelSize(R.dimen.color_swatch_size)
        val margin = (4 * resources.displayMetrics.density).roundToInt()

        viewModel.availableColors.forEach { option ->
            val swatch = View(this).apply {
                layoutParams = android.widget.LinearLayout.LayoutParams(swatchSize, swatchSize).apply {
                    setMargins(margin, 0, margin, 0)
                }
                background = buildSwatchDrawable(option.colorInt)
                contentDescription = option.name
                setOnClickListener {
                    viewModel.selectColor(option.colorInt)
                }
            }
            swatch.tag = option
            binding.colorPickerRow.addView(swatch)
        }
        refreshSwatchSelection()
    }

    private fun buildSwatchDrawable(color: Int): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
            setStroke(2, Color.parseColor("#40FFFFFF"))
        }
    }

    private fun refreshSwatchSelection() {
        val selected = viewModel.selectedColor.value ?: return
        for (i in 0 until binding.colorPickerRow.childCount) {
            val child = binding.colorPickerRow.getChildAt(i)
            val option = child.tag as? ColorOption ?: continue
            val drawable = buildSwatchDrawable(option.colorInt)
            if (option.colorInt == selected) {
                drawable.setStroke(6, Color.WHITE)
            }
            child.background = drawable
        }
    }

    private fun setupControlListeners() {
        binding.drawingView.currentBrushWidthPx = resources.getDimension(R.dimen.brush_default_size)

        binding.brushSizeSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val minPx = resources.getDimension(R.dimen.brush_min_size)
                val maxPx = resources.getDimension(R.dimen.brush_max_size)
                val px = minPx + (maxPx - minPx) * (progress / 44f)
                viewModel.setBrushSize(px)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        binding.btnUndo.setOnClickListener {
            if (!binding.drawingView.undo()) {
                toast(getString(R.string.toast_nothing_to_undo))
            }
        }

        binding.btnRedo.setOnClickListener {
            if (!binding.drawingView.redo()) {
                toast(getString(R.string.toast_nothing_to_redo))
            }
        }

        binding.btnClear.setOnClickListener { confirmClearCanvas() }

        binding.btnSave.setOnClickListener { saveDrawing() }

        binding.btnSwitchCamera.setOnClickListener {
            viewModel.toggleCameraFacing()
            fingertipFilter.reset()
            gestureRecognizer.reset()
            cameraController.switchCamera(binding.previewView) { proxy -> analyzeFrame(proxy) }
            viewModel.setFlashAvailable(cameraController.hasFlashUnit())
        }

        binding.btnFlash.setOnClickListener {
            if (!cameraController.hasFlashUnit()) {
                toast("Flash isn't available on this camera")
                return@setOnClickListener
            }
            viewModel.toggleFlash()
        }

        binding.drawingView.historyListener = object : com.toushif.airdrawai.drawing.DrawingView.HistoryListener {
            override fun onHistoryChanged(canUndo: Boolean, canRedo: Boolean) {
                viewModel.updateHistoryState(canUndo, canRedo)
            }
        }
    }

    private fun confirmClearCanvas() {
        AlertDialog.Builder(this)
            .setTitle(R.string.dialog_clear_title)
            .setMessage(R.string.dialog_clear_message)
            .setPositiveButton(R.string.dialog_clear_confirm) { _, _ ->
                binding.drawingView.clearCanvas()
                toast(getString(R.string.toast_canvas_cleared))
            }
            .setNegativeButton(R.string.dialog_clear_cancel, null)
            .show()
    }

    private fun saveDrawing() {
        val bitmap = binding.drawingView.exportBitmap()
        val uri = ImageSaver.saveBitmapAsPng(this, bitmap)
        if (uri != null) {
            toast(getString(R.string.toast_image_saved))
        } else {
            toast(getString(R.string.toast_image_save_failed))
        }
    }

    // endregion

    // region ViewModel observation

    private fun observeViewModel() {
        viewModel.selectedColor.observe(this) { color ->
            binding.drawingView.currentColor = color
            refreshSwatchSelection()
        }

        viewModel.brushSizePx.observe(this) { size ->
            binding.drawingView.currentBrushWidthPx = size
        }

        viewModel.canUndo.observe(this) { enabled ->
            setButtonEnabled(binding.btnUndo, enabled)
        }

        viewModel.canRedo.observe(this) { enabled ->
            setButtonEnabled(binding.btnRedo, enabled)
        }

        viewModel.isFlashOn.observe(this) { on ->
            binding.btnFlash.setImageResource(if (on) R.drawable.ic_flash_on else R.drawable.ic_flash_off)
            cameraController.setTorchEnabled(on && cameraController.hasFlashUnit())
        }

        viewModel.currentGesture.observe(this) { gesture ->
            binding.statusText.text = when (gesture) {
                HandGesture.DRAW -> getString(R.string.status_drawing)
                HandGesture.ERASE -> getString(R.string.status_erasing)
                HandGesture.PAUSE -> getString(R.string.status_paused)
                HandGesture.RESUME, HandGesture.NONE -> getString(R.string.status_no_hand)
            }
        }

        viewModel.handDetected.observe(this) { detected ->
            if (!detected) {
                binding.statusText.text = getString(R.string.status_no_hand)
            }
        }

        viewModel.currentFps.observe(this) { fps ->
            binding.fpsText.text = getString(R.string.fps_format, fps)
        }
    }

    private fun setButtonEnabled(button: ImageButton, enabled: Boolean) {
        button.isEnabled = enabled
        button.alpha = if (enabled) 1.0f else 0.4f
    }

    // endregion

    // region HandLandmarkerHelper.HandLandmarkerListener

    override fun onResults(resultBundle: HandLandmarkerHelper.ResultBundle) {
        runOnUiThread {
            updateFps()

            val landmarksList = resultBundle.result.landmarks()
            if (landmarksList.isNullOrEmpty()) {
                viewModel.updateHandDetected(false)
                viewModel.updateGesture(HandGesture.NONE)
                if (isDrawingActive) binding.drawingView.cancelActiveStroke()
                wasDrawingLastFrame = false
                wasErasingLastFrame = false
                return@runOnUiThread
            }

            viewModel.updateHandDetected(true)
            val landmarks: List<NormalizedLandmark> = landmarksList[0]
            val gesture = gestureRecognizer.recognize(landmarks)
            viewModel.updateGesture(gesture)
            handleGesture(gesture, landmarks, resultBundle.inputImageWidth, resultBundle.inputImageHeight)
        }
    }

    override fun onError(error: String) {
        runOnUiThread {
            Log.e(TAG, "HandLandmarker error: $error")
            toast(getString(R.string.toast_model_load_failed))
        }
    }

    // endregion

    private fun handleGesture(
        gesture: HandGesture,
        landmarks: List<NormalizedLandmark>,
        imageWidth: Int,
        imageHeight: Int
    ) {
        when (gesture) {
            HandGesture.PAUSE -> {
                isDrawingActive = false
                endActiveStrokesIfAny()
            }
            HandGesture.RESUME -> {
                isDrawingActive = true
                endActiveStrokesIfAny()
            }
            HandGesture.DRAW -> {
                if (!isDrawingActive) return
                val point = fingertipViewPoint(landmarks, imageWidth, imageHeight)
                if (wasErasingLastFrame) endActiveStrokesIfAny()
                if (!wasDrawingLastFrame) {
                    binding.drawingView.startStroke(point, isEraser = false)
                } else {
                    binding.drawingView.addPoint(point)
                }
                wasDrawingLastFrame = true
                wasErasingLastFrame = false
            }
            HandGesture.ERASE -> {
                if (!isDrawingActive) return
                val point = fingertipViewPoint(landmarks, imageWidth, imageHeight)
                if (wasDrawingLastFrame) endActiveStrokesIfAny()
                if (!wasErasingLastFrame) {
                    binding.drawingView.startStroke(point, isEraser = true)
                } else {
                    binding.drawingView.addPoint(point)
                }
                wasErasingLastFrame = true
                wasDrawingLastFrame = false
            }
            HandGesture.NONE -> {
                endActiveStrokesIfAny()
            }
        }
    }

    private fun endActiveStrokesIfAny() {
        if (wasDrawingLastFrame || wasErasingLastFrame) {
            binding.drawingView.endStroke()
            fingertipFilter.reset()
        }
        wasDrawingLastFrame = false
        wasErasingLastFrame = false
    }

    private fun fingertipViewPoint(
        landmarks: List<NormalizedLandmark>,
        imageWidth: Int,
        imageHeight: Int
    ): PointF {
        val tip = landmarks[HandLandmark.INDEX_FINGER_TIP]
        val viewPoint = CoordinateMapper.normalizedToView(
            normX = tip.x(),
            normY = tip.y(),
            imageWidth = imageWidth,
            imageHeight = imageHeight,
            viewWidth = binding.drawingView.width,
            viewHeight = binding.drawingView.height
        )
        val (fx, fy) = fingertipFilter.filter(viewPoint.x, viewPoint.y, System.nanoTime())
        return PointF(fx, fy)
    }

    private fun updateFps() {
        frameCount++
        val now = System.currentTimeMillis()
        val elapsed = now - lastFpsTimestamp
        if (elapsed >= 1000) {
            val fps = (frameCount * 1000f / elapsed).roundToInt()
            viewModel.updateFps(fps)
            frameCount = 0
            lastFpsTimestamp = now
        }
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        handLandmarkerHelper?.clear()
        cameraController.shutdown()
    }

    companion object {
        private const val TAG = "MainActivity"
    }
}
