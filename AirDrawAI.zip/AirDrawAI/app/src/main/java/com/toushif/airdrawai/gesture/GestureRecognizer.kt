package com.toushif.airdrawai.gesture

import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.toushif.airdrawai.model.HandGesture
import com.toushif.airdrawai.model.HandLandmark
import kotlin.math.sqrt

/**
 * Classifies a [HandGesture] from a single hand's 21 normalized landmarks.
 *
 * The classification is purely geometric (no ML model beyond the landmarks
 * themselves), which keeps it fast enough to run every frame:
 *
 *  - A finger is considered "extended" if its tip is farther from the wrist
 *    than its PIP joint, AND farther than its MCP joint by a safety margin.
 *    This is more robust to hand rotation than a simple y-coordinate check.
 *  - DRAW: only the index finger extended.
 *  - ERASE: index + middle fingers extended, ring & pinky curled.
 *  - PAUSE: fist — no fingers extended.
 *  - RESUME: open palm — all four fingers (+ thumb loosely) extended.
 */
class GestureRecognizer {

    private var lastStableGesture: HandGesture = HandGesture.NONE
    private var candidateGesture: HandGesture = HandGesture.NONE
    private var candidateCount: Int = 0

    /** Number of consecutive identical frames required before a gesture change is accepted. */
    private val stabilityThreshold = 3

    fun recognize(landmarks: List<NormalizedLandmark>): HandGesture {
        if (landmarks.size < HandLandmark.NUM_LANDMARKS) return debounce(HandGesture.NONE)

        val indexUp = isFingerExtended(
            landmarks, HandLandmark.INDEX_FINGER_TIP, HandLandmark.INDEX_FINGER_PIP, HandLandmark.INDEX_FINGER_MCP
        )
        val middleUp = isFingerExtended(
            landmarks, HandLandmark.MIDDLE_FINGER_TIP, HandLandmark.MIDDLE_FINGER_PIP, HandLandmark.MIDDLE_FINGER_MCP
        )
        val ringUp = isFingerExtended(
            landmarks, HandLandmark.RING_FINGER_TIP, HandLandmark.RING_FINGER_PIP, HandLandmark.RING_FINGER_MCP
        )
        val pinkyUp = isFingerExtended(
            landmarks, HandLandmark.PINKY_TIP, HandLandmark.PINKY_PIP, HandLandmark.PINKY_MCP
        )
        val thumbUp = isThumbExtended(landmarks)

        val raw = when {
            indexUp && middleUp && !ringUp && !pinkyUp -> HandGesture.ERASE
            indexUp && !middleUp && !ringUp && !pinkyUp -> HandGesture.DRAW
            !indexUp && !middleUp && !ringUp && !pinkyUp && !thumbUp -> HandGesture.PAUSE
            indexUp && middleUp && ringUp && pinkyUp -> HandGesture.RESUME
            else -> HandGesture.NONE
        }

        return debounce(raw)
    }

    /** Requires a few consecutive matching frames before switching gestures, to avoid flicker. */
    private fun debounce(raw: HandGesture): HandGesture {
        if (raw == candidateGesture) {
            candidateCount++
        } else {
            candidateGesture = raw
            candidateCount = 1
        }
        if (candidateCount >= stabilityThreshold) {
            lastStableGesture = candidateGesture
        }
        return lastStableGesture
    }

    private fun isFingerExtended(
        landmarks: List<NormalizedLandmark>,
        tipIdx: Int,
        pipIdx: Int,
        mcpIdx: Int
    ): Boolean {
        val wrist = landmarks[HandLandmark.WRIST]
        val tip = landmarks[tipIdx]
        val pip = landmarks[pipIdx]
        val mcp = landmarks[mcpIdx]

        val tipToWrist = distance(tip.x(), tip.y(), wrist.x(), wrist.y())
        val pipToWrist = distance(pip.x(), pip.y(), wrist.x(), wrist.y())
        val mcpToWrist = distance(mcp.x(), mcp.y(), wrist.x(), wrist.y())

        // Extended fingers have their tip clearly farther from the wrist than
        // both intermediate joints.
        return tipToWrist > pipToWrist && tipToWrist > mcpToWrist * 1.15f
    }

    private fun isThumbExtended(landmarks: List<NormalizedLandmark>): Boolean {
        val wrist = landmarks[HandLandmark.WRIST]
        val tip = landmarks[HandLandmark.THUMB_TIP]
        val mcp = landmarks[HandLandmark.THUMB_MCP]
        val tipToWrist = distance(tip.x(), tip.y(), wrist.x(), wrist.y())
        val mcpToWrist = distance(mcp.x(), mcp.y(), wrist.x(), wrist.y())
        return tipToWrist > mcpToWrist * 1.1f
    }

    private fun distance(x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x1 - x2
        val dy = y1 - y2
        return sqrt((dx * dx + dy * dy).toDouble()).toFloat()
    }

    fun reset() {
        lastStableGesture = HandGesture.NONE
        candidateGesture = HandGesture.NONE
        candidateCount = 0
    }
}
