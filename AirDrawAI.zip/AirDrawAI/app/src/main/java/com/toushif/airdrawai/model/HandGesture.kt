package com.toushif.airdrawai.model

/**
 * Recognized hand gestures that drive the app's drawing state machine.
 */
enum class HandGesture {
    /** Only the index finger is extended — active drawing. */
    DRAW,

    /** Index + middle fingers extended — eraser mode. */
    ERASE,

    /** All fingers curled into a fist — pause drawing/erasing. */
    PAUSE,

    /** All five fingers extended (open palm) — resume from pause. */
    RESUME,

    /** No hand detected, or a pose that doesn't map to any known gesture. */
    NONE
}

/**
 * MediaPipe Hand Landmarker returns 21 landmarks per hand, indexed as follows.
 * See: https://ai.google.dev/edge/mediapipe/solutions/vision/hand_landmarker
 */
object HandLandmark {
    const val WRIST = 0

    const val THUMB_CMC = 1
    const val THUMB_MCP = 2
    const val THUMB_IP = 3
    const val THUMB_TIP = 4

    const val INDEX_FINGER_MCP = 5
    const val INDEX_FINGER_PIP = 6
    const val INDEX_FINGER_DIP = 7
    const val INDEX_FINGER_TIP = 8

    const val MIDDLE_FINGER_MCP = 9
    const val MIDDLE_FINGER_PIP = 10
    const val MIDDLE_FINGER_DIP = 11
    const val MIDDLE_FINGER_TIP = 12

    const val RING_FINGER_MCP = 13
    const val RING_FINGER_PIP = 14
    const val RING_FINGER_DIP = 15
    const val RING_FINGER_TIP = 16

    const val PINKY_MCP = 17
    const val PINKY_PIP = 18
    const val PINKY_DIP = 19
    const val PINKY_TIP = 20

    const val NUM_LANDMARKS = 21
}
