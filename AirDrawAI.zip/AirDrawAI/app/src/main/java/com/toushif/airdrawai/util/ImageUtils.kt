package com.toushif.airdrawai.util

import android.graphics.Bitmap
import android.graphics.Matrix
import androidx.camera.core.ImageProxy

/**
 * Converts a CameraX [ImageProxy] (RGBA_8888 output format, configured on
 * the ImageAnalysis use case) into a correctly rotated [Bitmap] ready to
 * feed into MediaPipe.
 */
object ImageUtils {

    fun imageProxyToBitmap(imageProxy: ImageProxy, isFrontCamera: Boolean): Bitmap {
        val bitmapBuffer = Bitmap.createBitmap(
            imageProxy.width,
            imageProxy.height,
            Bitmap.Config.ARGB_8888
        )
        bitmapBuffer.copyPixelsFromBuffer(imageProxy.planes[0].buffer)

        val matrix = Matrix().apply {
            postRotate(imageProxy.imageInfo.rotationDegrees.toFloat())
            if (isFrontCamera) {
                // Mirror the front camera output so drawing feels natural
                // (moving your hand right moves the trail right on screen).
                postScale(-1f, 1f, imageProxy.width / 2f, imageProxy.height / 2f)
            }
        }

        return Bitmap.createBitmap(
            bitmapBuffer, 0, 0, bitmapBuffer.width, bitmapBuffer.height, matrix, true
        )
    }
}
