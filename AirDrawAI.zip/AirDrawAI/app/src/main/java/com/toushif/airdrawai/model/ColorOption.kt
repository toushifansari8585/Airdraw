package com.toushif.airdrawai.model

import androidx.annotation.ColorInt

/**
 * A selectable brush color shown in the color picker strip.
 */
data class ColorOption(
    val name: String,
    @ColorInt val colorInt: Int
)

/**
 * A single freehand stroke made up of connected points, along with the
 * paint properties it was drawn with. Immutable so it can be safely pushed
 * onto the undo/redo stacks.
 */
data class Stroke(
    val points: MutableList<android.graphics.PointF> = mutableListOf(),
    @ColorInt val color: Int,
    val strokeWidth: Float,
    val isEraser: Boolean = false
)
