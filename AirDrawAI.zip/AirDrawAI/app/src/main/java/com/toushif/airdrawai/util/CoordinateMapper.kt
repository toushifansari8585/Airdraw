package com.toushif.airdrawai.util

import android.graphics.PointF

/**
 * Maps a normalized (0..1) landmark coordinate — relative to the analyzed
 * camera frame — into pixel coordinates on the overlay [DrawingView], which
 * sits above a [androidx.camera.view.PreviewView] using the default
 * FILL_CENTER scale type (crop-to-fill, centered).
 */
object CoordinateMapper {

    fun normalizedToView(
        normX: Float,
        normY: Float,
        imageWidth: Int,
        imageHeight: Int,
        viewWidth: Int,
        viewHeight: Int
    ): PointF {
        if (imageWidth <= 0 || imageHeight <= 0 || viewWidth <= 0 || viewHeight <= 0) {
            return PointF(0f, 0f)
        }

        val scale = maxOf(
            viewWidth.toFloat() / imageWidth.toFloat(),
            viewHeight.toFloat() / imageHeight.toFloat()
        )

        val scaledImageWidth = imageWidth * scale
        val scaledImageHeight = imageHeight * scale
        val offsetX = (viewWidth - scaledImageWidth) / 2f
        val offsetY = (viewHeight - scaledImageHeight) / 2f

        val viewX = normX * imageWidth * scale + offsetX
        val viewY = normY * imageHeight * scale + offsetY

        return PointF(viewX, viewY)
    }
}
