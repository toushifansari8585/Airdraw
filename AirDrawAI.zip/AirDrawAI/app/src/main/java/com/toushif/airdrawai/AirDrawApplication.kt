package com.toushif.airdrawai

import android.app.Application

/**
 * Application entry point. Kept intentionally lightweight — used for any
 * process-wide initialization (e.g. crash reporting) without leaking
 * Activity-scoped resources.
 */
class AirDrawApplication : Application() {

    override fun onCreate() {
        super.onCreate()
    }
}
